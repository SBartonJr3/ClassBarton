#Stephen Barton Jr
#Python Programming, treadmill
#22 APR 2019

def main():
    burn = 10
    while 30 >= burn >= 10:
        cal = 3.9
        total = burn * cal
        print(total, "calories burned")
        burn = burn + 5

main()
