#Stephen Barton Jr
#Python Programming, square pattern
#22 APR 2019

def main():
    for i in range(1,11):
        j = i * i
        print(j, end = " ")

main()
    
