#Stephen Barton Jr
#Python Programming, product
#22 APR 2019

def main():
    product = 0
    while product < 100:
        number = int(input("Enter a number: "))
        product = number * 10
        print(product)

main()
