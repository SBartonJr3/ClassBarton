#Stephen Barton Jr
#Python Programming, ifelse
#22 APR 2019

def main():
    a = int(input("Enter a number: "))
    if a < 10:
        b = 0
        print("b is", b)
    else:
        b = 99
        print("b is", b)

main()
