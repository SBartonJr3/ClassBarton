#Stephen Barton Jr
#Python Programming, star pattern
#22 APR 2019

def main():
    for i in range(1,6):
        for j in range(1,i+1):
            print("*", end = " ")
        print()

main()
            
