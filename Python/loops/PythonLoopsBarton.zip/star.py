#Stephen Barton Jr
#Python Programming, star
#22 APR 2019

def main():
    for i in range (1,5):
        print("*****")

main()
