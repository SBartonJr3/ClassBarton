#Stephen Barton Jr
#Python Programming, a less than 10
#22 APR 2019

def main():
    a = 7
    if a < 10:
        b = 0
        c = 1
        print("b is",b)
        print("c is",c)

main()
