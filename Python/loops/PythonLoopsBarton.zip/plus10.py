#Stephen Barton Jr
#Python Programming, plus 10
#22 APR 2019

def main():
    for i in range(0,101):
        a = i * 10
        print(a, end = " ")

main()
        
