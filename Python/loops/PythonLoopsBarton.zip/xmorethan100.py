#Stephen Barton Jr
#Python Programming, x more than 100
#22 APR 2019

def main():
    x = 101
    if x > 100:
        y = 20
        z = 40
        print("y is",y)
        print("z is",z)

main()
    
