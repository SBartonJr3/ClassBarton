#Stephen Barton Jr
#Python Programming, hex
#22 APR 2019

def main():
    decimal = int(input("Enter a number: "))
    if decimal > 0:
        print(hex(decimal))

main()
        
