#Stephen Barton Jr
#Python Programming, ascii art
#22 APR 2019

def main():
    a()
    b()
    print()
    b()
    a()
    print()
    a()
    c()
    d()
    c()
    a()

def a():
        print("   /\\")
        print("  /  \\")
        print(" /    \\")

def b():
        print(" \\    /")
        print("  \\  /")
        print("   \\/")

def c():
        print("+------+")
        print("|      |")
        print("|      |")
        print("+------+")

def d():
        print("|United|")
        print("|States|")

main()
