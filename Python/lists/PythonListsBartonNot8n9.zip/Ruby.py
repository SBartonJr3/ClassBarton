#Stehen Barton Jr
#24 APR 2019
#Python Exercises, No Ruby

def main():
    names = ["Einstein", "Newton", "Copernicus", "Kepler", "Ruby"]

    if "Ruby" in names:
        print("Hello Ruby")
    else:
        print("No Ruby")

main()
