#Stehen Barton Jr
#24 APR 2019
#Python Exercises, names

def main():
    names = ["Einstein", "Newton", "Copernicus", "Kepler"]

    i = 0
    for i in range(0,len(names)):
        print(names[i])
        i += 1
main()
