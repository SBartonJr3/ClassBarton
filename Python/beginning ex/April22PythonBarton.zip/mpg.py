#Stephen Barton Jr
#Python Programming, MPG
#22 APR 2019

miles = float(input("Enter the amount of miles that you traveled today: "))
gallons = float(input("Enter the amount of gallons that you used today: "))
MPG = miles / gallons
print('Your car gets',format(MPG, '.2f'), 'MPG')
             
