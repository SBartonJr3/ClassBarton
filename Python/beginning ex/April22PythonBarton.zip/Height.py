#Stephen Barton Jr
#Python Exercise, Prompt for user Height
#22 APR 2019


he1ght = int(input("Input your height in inches: "))
print('Your height is',he1ght,'inches')
