#Stephen Barton Jr
#Python Programming, Profit
#22 APR 2019

sales = int(input("Input your projected sales for the year: "))
profit = sales * .23
print("The total profit for the year will be: ",profit)
