#Stephen Barton Jr
#Python Exercise, Prompt for favorite color
#22 APR 2019

color = input("Buddy the Elf, what's your favorite color? : ")
print('Your favorite color is: ',color)
