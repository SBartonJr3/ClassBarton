#Stephen Barton Jr
#Python Exercise, Assignment Statements
#22 APR 2019

a = 5
print(a)
b = a + 2
print(b)
a = b * 4
print(a)
b = a / 3.14
print(b)
a = b - 8
print(a)
