#Stephen Barton Jr
#Python Programming, feet to meters
#22 APR 2019

feet = float(input("Enter the amount of feet you want to convert to meters: "))
meters = feet * .305
print(format(feet, '.2f'),"feet is", format(meters, '.4f'), "meters")
