#Stephen Barton Jr
#Python Programming, temperature
#22 APR 2019

celsius = float(input("Enter the degrees in Celsius: "))
fahren = 9/5 * celsius + 32
print("Converted to Fahrenheit is:",format(fahren, '.2f'), "degrees")
